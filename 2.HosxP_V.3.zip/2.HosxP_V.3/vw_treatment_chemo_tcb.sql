DROP VIEW vw_treatment_chemo_tcb;

CREATE VIEW vw_treatment_chemo_tcb AS
SELECT * 
FROM (
    SELECT 
        CONCAT(SUBSTRING(p.cid, 1, 1), '-', SUBSTRING(p.cid, 2, 4), '-', SUBSTRING(p.cid, 6, 5), '-', SUBSTRING(p.cid, 11, 2), '-', SUBSTRING(p.cid, 13, 1)) AS cid, 
        DATE_FORMAT(o.vstdate, "%Y%m%d") AS visit_date,
        '3' AS treatment_code,
        DATE_FORMAT(pcr.patient_cancer_first_diag_cancer_date, "%Y%m%d") AS treatment_start_date,
        (select upper(replace(od.icd10, '.', ''))  
          from ovstdiag od 
          where od.vn = o.vn
          and od.diagtype = '1' 
          and upper(od.icd10) LIKE 'C%') AS icd10_code
    FROM 
        ovst o
				LEFT OUTER JOIN ovstdiag od ON o.vn = od.vn
        LEFT OUTER JOIN patient_cancer_registeration pcr ON o.hn = pcr.hn
        LEFT OUTER JOIN patient p ON p.hn = o.hn
    WHERE o.vstdate = CURDATE()
		
		AND (od.icd10 IN ("9925", "9928", "9929")
			or o.vn in (select vn from ovstoprt where vn = o.vn and icd9cm in ("9925", "9928", "9929")))
) DAT 
WHERE icd10_code IS NOT NULL;