DROP VIEW vw_treatment_surgery_tcb;

CREATE VIEW vw_treatment_surgery_tcb AS
SELECT * 
FROM (
    SELECT o.hn,
        CONCAT(SUBSTRING(p.cid, 1, 1), '-', SUBSTRING(p.cid, 2, 4), '-', SUBSTRING(p.cid, 6, 5), '-', SUBSTRING(p.cid, 11, 2), '-', SUBSTRING(p.cid, 13, 1)) AS cid, 
        DATE_FORMAT(o.vstdate, "%Y%m%d") AS visit_date,
        '1' AS treatment_code,
        DATE_FORMAT(pcr.patient_cancer_first_diag_cancer_date, "%Y%m%d") AS treatment_start_date,
        (select upper(replace(od.icd10, '.', ''))  
          from ovstdiag od 
          where od.vn = o.vn
          and od.diagtype = '1' 
          and upper(od.icd10) LIKE 'C%') AS icd10_code
    FROM 
        ovst o
				LEFT OUTER JOIN ovstdiag od ON o.vn = od.vn
        LEFT OUTER JOIN patient_cancer_registeration pcr ON o.hn = pcr.hn
        LEFT OUTER JOIN patient p ON p.hn = o.hn
    WHERE o.vstdate = CURDATE()
		
		AND o.an in (select an from operation_list where an = o.an and (an <> '' or an is not null))
			
) DAT 
WHERE icd10_code IS NOT NULL;