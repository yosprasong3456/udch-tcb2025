DROP VIEW "public"."vw_cancer_tcb";

CREATE VIEW "public"."vw_cancer_tcb" AS SELECT
CASE
		
	WHEN
		o.pttype = '10' :: BPCHAR THEN
			1 
			WHEN o.pttype = '01' :: BPCHAR THEN
			2 
			WHEN pt.hipdata_code :: TEXT = 'SSS' :: TEXT THEN
			3 
			WHEN pt.hipdata_code :: TEXT = 'UCS' :: TEXT 
			AND ( o.pttype <> ALL ( ARRAY [ '10' :: BPCHAR, '01' :: BPCHAR ] ) ) THEN
				4 ELSE 9 
				END AS finance_support_code,
			pt.NAME,
			(
				(
					(
						(
							(
								(
									( "left" ( P.CID :: TEXT, 1 ) || '-' :: TEXT ) || SUBSTRING ( P.CID FROM 2 FOR 4 ) 
								) || '-' :: TEXT 
							) || SUBSTRING ( P.CID FROM 6 FOR 5 ) 
						) || '-' :: TEXT 
					) || SUBSTRING ( P.CID FROM 11 FOR 2 ) 
				) || '-' :: TEXT 
			) || "right" ( P.CID :: TEXT, 1 ) AS CID,
			to_char( o.vstdate :: TIMESTAMP WITH TIME ZONE, 'YYYYMMDD' :: TEXT ) AS visit_date,
			od.icd10 AS icd10_code,
			'3' :: TEXT AS behaviour_code,
			'1' :: TEXT AS diagnosis_code,
			'8000' :: TEXT AS morphology,
			'' :: TEXT AS grade,
			'' :: TEXT AS stage,
			'' :: TEXT AS T,
			'' :: TEXT AS n,
			'' :: TEXT AS M,
			'' :: TEXT AS recurrent,
			'' :: TEXT AS recurrent_date,
			'' :: TEXT AS clinical_summary 
		FROM
			ovst o
			LEFT JOIN patient P ON o.hn :: TEXT = P.hn ::
			TEXT LEFT JOIN pttype pt ON o.pttype = pt.pttype
			LEFT JOIN ovstdiag od ON o.vn :: TEXT = od.vn :: TEXT 
			AND od.diagtype = '1' :: BPCHAR 
		WHERE
			o.vstdate = CURRENT_DATE 
			AND (
			o.main_dep = ANY ( ARRAY [ '310' :: BPCHAR, '356' :: BPCHAR, '357' :: BPCHAR, '358' :: BPCHAR, '374' :: BPCHAR ] ) 
	);

ALTER TABLE "public"."vw_cancer_tcb" OWNER TO "root";