DROP VIEW "public"."vw_patient_tcb";

CREATE VIEW "public"."vw_patient_tcb" AS SELECT
	o.hn,
	P.pname,
CASE
		
		WHEN P.pname :: TEXT = 'นาย' :: TEXT THEN
		1 
		WHEN P.pname :: TEXT = 'นาง' :: TEXT THEN
		2 
		WHEN P.pname :: TEXT ~~ '%น.ส.%' :: TEXT 
		OR P.pname :: TEXT ~~ '%นางสาว%' :: TEXT THEN
			3 
			WHEN P.pname :: TEXT ~~ '%ด.ช.%' :: TEXT 
			OR P.pname :: TEXT ~~ '%เด็กชาย%' :: TEXT THEN
				4 
				WHEN P.pname :: TEXT ~~ '%ด.ญ.%' :: TEXT 
				OR P.pname :: TEXT ~~ '%เด็กหญิง%' :: TEXT THEN
					5 
					WHEN P.pname :: TEXT ~~ '%พระ%' :: TEXT 
					OR P.pname :: TEXT ~~ '%ภิกษุ%' :: TEXT THEN
						6 ELSE 99 
						END AS title_code,
					P.fname AS NAME,
					P.lname AS last_name,
					to_char( P.birthday :: TIMESTAMP WITH TIME ZONE, 'YYYYMMDD' :: TEXT ) AS birth_date,
					(
						(
							(
								(
									(
										(
											( "left" ( P.CID :: TEXT, 1 ) || '-' :: TEXT ) || SUBSTRING ( P.CID FROM 2 FOR 4 ) 
										) || '-' :: TEXT 
									) || SUBSTRING ( P.CID FROM 6 FOR 5 ) 
								) || '-' :: TEXT 
							) || SUBSTRING ( P.CID FROM 11 FOR 2 ) 
						) || '-' :: TEXT 
					) || "right" ( P.CID :: TEXT, 1 ) AS CID,
					P.sex AS sex_code,
					P.addrpart AS address_no,
					P.moopart AS address_moo,
					concat ( P.addrpart, ' หมู่ ', P.moopart ) AS address,
					t3.NAME AS tb,
					t2.NAME AS ap,
					t1.NAME AS provice,
					t3.addressid AS area_code,
					P.addrpart AS permanent_address_no,
					P.moopart AS permanent_address_moo,
					t3.addressid AS permanent_area_code,
					P.mobile_phone_number AS telephone_1 
				FROM
					ovst o
					LEFT JOIN patient P ON o.hn :: TEXT = P.hn ::
					TEXT LEFT JOIN thaiaddress t1 ON t1.chwpart = P.chwpart 
					AND t1.amppart = '00' :: BPCHAR 
					AND t1.tmbpart = '00' ::
					BPCHAR LEFT JOIN thaiaddress t2 ON t2.chwpart = P.chwpart 
					AND t2.amppart = P.amppart 
					AND t2.tmbpart = '00' ::
					BPCHAR LEFT JOIN thaiaddress t3 ON t3.chwpart = P.chwpart 
					AND t3.amppart = P.amppart 
					AND t3.tmbpart = P.tmbpart 
				WHERE
					o.vstdate = CURRENT_DATE 
					AND (
					o.main_dep = ANY ( ARRAY [ '310' :: BPCHAR, '356' :: BPCHAR, '357' :: BPCHAR, '358' :: BPCHAR, '374' :: BPCHAR ] ) 
	);

ALTER TABLE "public"."vw_patient_tcb" OWNER TO "root";